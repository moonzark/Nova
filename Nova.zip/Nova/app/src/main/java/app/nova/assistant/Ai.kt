package app.nova.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class AiError(message: String) : Exception(message)

/** Бесплатный ИИ: Groq (ключ начинается с gsk_) или Gemini (ключ начинается с AIza). */
object Ai {
    private val GROQ_MODELS = listOf("llama-3.3-70b-versatile", "llama-3.1-8b-instant")
    private val GEMINI_MODELS = listOf("gemini-2.5-flash", "gemini-2.0-flash")

    fun ask(ctx: Context, userText: String): String {
        val key = Store.apiKey(ctx)
        val hist = Store.history(ctx, 12)
        val sys = systemPrompt(ctx)
        val answer = when {
            key.startsWith("gsk_") -> askGroq(key, sys, hist, userText)
            key.startsWith("AIza") -> askGemini(key, sys, hist, userText)
            else -> throw AiError("Не узнаю этот ключ. Проверь его в настройках приложения.")
        }
        val clean = cleanForSpeech(answer)
        if (clean.isBlank()) throw AiError("ИИ ничего не ответил.")
        Store.addHistory(ctx, "user", userText)
        Store.addHistory(ctx, "assistant", clean)
        return clean
    }

    /** Один вопрос без истории. */
    fun oneShot(ctx: Context, system: String, user: String): String {
        val key = Store.apiKey(ctx)
        return when {
            key.startsWith("gsk_") -> askGroq(key, system, emptyList(), user)
            key.startsWith("AIza") -> askGemini(key, system, emptyList(), user)
            else -> throw AiError("Нет ключа ИИ.")
        }
    }

    /** ИИ выбирает приложение из установленных по неточной фразе. Возвращает пакет или null. */
    fun pickApp(ctx: Context, spoken: String, apps: List<Pair<String, String>>): String? {
        val list = apps.joinToString("\n") { it.first + " | " + it.second }
        val ans = oneShot(
            ctx,
            "Ты выбираешь приложение на телефоне. Тебе дают список строк «название | пакет» и фразу " +
                    "пользователя (она может быть с ошибками распознавания речи, по-русски или " +
                    "по-английски). Ответь ТОЛЬКО пакетом (часть после «|») подходящего приложения. " +
                    "Если подходящего нет, ответь NONE.",
            "Список:\n$list\n\nФраза: открой $spoken"
        )
        val pkg = ans.trim().lines().firstOrNull()?.trim()?.trim('`', '"', ' ', '.') ?: return null
        return apps.firstOrNull { it.second == pkg }?.second
    }

    private fun systemPrompt(ctx: Context): String {
        val now = SimpleDateFormat("EEEE, d MMMM yyyy, H:mm", Locale("ru")).format(Date())
        var s = "Ты ${Config.NAME} — добрый, дружелюбный и немного игривый голосовой ассистент на телефоне. " +
                "Отвечай по-русски, коротко (одно-три предложения), простым разговорным языком. " +
                "Не используй markdown, списки, эмодзи и ссылки: твой ответ будет озвучен голосом. " +
                "Сейчас: $now."
        val notes = Store.notes(ctx)
        if (notes.isNotEmpty()) {
            s += " Пользователь просил запомнить: " + notes.joinToString("; ") + "."
        }
        return s
    }

    private fun cleanForSpeech(s: String): String =
        s.replace(Regex("[*#`_>]"), "")
            .replace(Regex("https?://\\S+"), "")
            .replace("\n", " ")
            .replace(Regex("\\s+"), " ")
            .trim()

    private fun post(url: String, headers: Map<String, String>, body: String): Pair<Int, String> {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 10_000
            c.readTimeout = 30_000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            c.setRequestProperty("User-Agent", "Nova-Android/0.3")
            for ((k, v) in headers) c.setRequestProperty(k, v)
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            return code to text
        } finally {
            c.disconnect()
        }
    }

    private fun get(url: String, headers: Map<String, String>): Pair<Int, String> {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = "GET"
            c.connectTimeout = 10_000
            c.readTimeout = 20_000
            c.setRequestProperty("User-Agent", "Nova-Android/0.3")
            for ((k, v) in headers) c.setRequestProperty(k, v)
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            return code to text
        } finally {
            c.disconnect()
        }
    }

    private var groqCacheKey = ""
    private var groqCache: List<String> = emptyList()

    /** Спрашивает у Groq, какие модели доступны этому ключу, и сортирует по пригодности. */
    private fun groqModels(key: String): List<String> {
        if (key == groqCacheKey && groqCache.isNotEmpty()) return groqCache
        var avail: List<String> = emptyList()
        try {
            val (code, text) = get(
                "https://api.groq.com/openai/v1/models",
                mapOf("Authorization" to "Bearer $key")
            )
            if (code in 200..299) {
                val arr = JSONObject(text).getJSONArray("data")
                val ids = ArrayList<String>()
                for (i in 0 until arr.length()) ids.add(arr.getJSONObject(i).getString("id"))
                avail = ids
            } else if (code == 401 || code == 403) {
                throw failure(code, text)
            } else {
                Status.set("ИИ: список моделей, ошибка $code ${text.take(60)}")
            }
        } catch (e: AiError) {
            throw e
        } catch (e: Exception) {
            Status.set("ИИ: список моделей не получен: ${e.message}")
        }
        val bad = listOf("whisper", "guard", "tts", "playai", "orpheus", "embed", "compound", "safeguard")
        val chat = avail.filter { id -> bad.none { id.contains(it, ignoreCase = true) } }
        val preferred = GROQ_MODELS.filter { it in chat }
        val rest = chat.filter { it !in preferred }.sortedBy { id ->
            when {
                id.contains("llama", true) -> 0
                id.contains("gpt-oss", true) -> 1
                id.contains("qwen", true) -> 2
                else -> 3
            }
        }
        val result = (preferred + rest).take(5).ifEmpty { GROQ_MODELS }
        if (avail.isNotEmpty()) {
            groqCacheKey = key
            groqCache = result
        }
        return result
    }

    private fun failure(code: Int, body: String): AiError {
        Status.set("ИИ: ошибка $code ${body.take(80)}")
        return when (code) {
            401, 403 -> AiError("Ключ не подходит. Проверь его в настройках приложения.")
            429 -> AiError("Слишком много запросов. Подожди минуту.")
            404, 400 -> AiError("Модель ИИ недоступна для этого ключа.")
            else -> AiError("ИИ сейчас не отвечает.")
        }
    }

    private fun askGroq(
        key: String, sys: String, hist: List<Pair<String, String>>, user: String
    ): String {
        val msgs = JSONArray()
        msgs.put(JSONObject().put("role", "system").put("content", sys))
        for ((r, x) in hist) msgs.put(JSONObject().put("role", r).put("content", x))
        msgs.put(JSONObject().put("role", "user").put("content", user))
        var last: AiError? = null
        for (model in groqModels(key)) {
            val body = JSONObject()
                .put("model", model)
                .put("messages", msgs)
                .put("max_tokens", 300)
                .put("temperature", 0.8)
                .toString()
            val (code, text) = post(
                "https://api.groq.com/openai/v1/chat/completions",
                mapOf("Authorization" to "Bearer $key"), body
            )
            if (code in 200..299) {
                return JSONObject(text).getJSONArray("choices").getJSONObject(0)
                    .getJSONObject("message").getString("content")
            }
            last = failure(code, text)
            if (code == 401 || code == 403) break
        }
        throw last ?: AiError("ИИ сейчас не отвечает.")
    }

    private fun askGemini(
        key: String, sys: String, hist: List<Pair<String, String>>, user: String
    ): String {
        val contents = JSONArray()
        var started = false
        for ((r, x) in hist) {
            val role = if (r == "assistant") "model" else "user"
            if (!started && role == "model") continue
            started = true
            contents.put(
                JSONObject().put("role", role)
                    .put("parts", JSONArray().put(JSONObject().put("text", x)))
            )
        }
        contents.put(
            JSONObject().put("role", "user")
                .put("parts", JSONArray().put(JSONObject().put("text", user)))
        )
        var last: AiError? = null
        for (model in GEMINI_MODELS) {
            val body = JSONObject()
                .put(
                    "systemInstruction",
                    JSONObject().put("parts", JSONArray().put(JSONObject().put("text", sys)))
                )
                .put("contents", contents)
                .toString()
            val (code, text) = post(
                "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent",
                mapOf("x-goog-api-key" to key), body
            )
            if (code in 200..299) {
                val parts = JSONObject(text).getJSONArray("candidates").getJSONObject(0)
                    .getJSONObject("content").getJSONArray("parts")
                val sb = StringBuilder()
                for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text"))
                return sb.toString()
            }
            last = failure(code, text)
            if (code == 401 || code == 403) break
        }
        throw last ?: AiError("ИИ сейчас не отвечает.")
    }
}

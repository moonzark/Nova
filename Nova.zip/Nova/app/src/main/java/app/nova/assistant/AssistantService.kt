package app.nova.assistant

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService
import java.io.IOException

class AssistantService : Service() {

    companion object {
        const val ACTION_STOP = "app.nova.assistant.STOP"
        private const val CHANNEL_ID = "nova"
        private const val NOTIF_ID = 1
    }

    private var model: Model? = null
    private var speech: SpeechService? = null
    private var speaker: Speaker? = null
    private lateinit var router: CommandRouter
    private var awakeUntil = 0L
    private val main = Handler(Looper.getMainLooper())

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        router = CommandRouter(applicationContext) { text ->
            main.post {
                awakeUntil = System.currentTimeMillis() + Config.FOLLOWUP_MS
                speaker?.say(text)
            }
        }
        speaker = Speaker(
            this,
            onSpeakStart = { speech?.setPause(true) },
            onSpeakEnd = { main.postDelayed({ speech?.setPause(false) }, 350) }
        )
        main.postDelayed(ticker, 15_000)
    }

    /** Раз в 15 секунд проверяет, не пора ли озвучить напоминание. */
    private val ticker: Runnable = object : Runnable {
        override fun run() {
            val due = Store.takeDue(applicationContext)
            if (due.isNotEmpty()) {
                speaker?.say("Напоминаю: " + due.joinToString(". "))
            }
            main.postDelayed(this, 15_000)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            Status.set("Нет доступа к микрофону")
            stopSelf()
            return START_NOT_STICKY
        }
        startInForeground()
        if (model == null) loadModel() else startListening()
        return START_STICKY
    }

    private fun startInForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Nova", NotificationManager.IMPORTANCE_LOW)
        )
        val stop = PendingIntent.getService(
            this, 0,
            Intent(this, AssistantService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("Nova слушает")
            .setContentText("Скажи «Нова»")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .addAction(Notification.Action.Builder(null, "Остановить", stop).build())
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    private fun loadModel() {
        Thread {
            try {
                if (!ModelManager.isReady(this)) {
                    Status.set("Скачиваю модель речи (~45 МБ)…")
                    ModelManager.download(this) { p -> Status.set("Скачиваю модель: $p%") }
                }
                Status.set("Загрузка модели…")
                val m = Model(ModelManager.modelPath(this))
                main.post {
                    model = m
                    startListening()
                }
            } catch (e: Exception) {
                Status.set("Ошибка модели: ${e.message}")
            }
        }.start()
    }

    private fun startListening() {
        val m = model ?: return
        try {
            speech?.stop()
            speech?.shutdown()
            val rec = Recognizer(m, 16000.0f)
            speech = SpeechService(rec, 16000.0f)
            speech?.startListening(listener)
            Status.set("Слушаю: скажи «Нова»")
        } catch (e: IOException) {
            Status.set("Ошибка микрофона: ${e.message}")
        }
    }

    private val listener = object : RecognitionListener {
        override fun onPartialResult(hypothesis: String?) {}
        override fun onResult(hypothesis: String?) {
            val text = try {
                JSONObject(hypothesis ?: "{}").optString("text")
            } catch (e: Exception) {
                ""
            }
            handleText(text)
        }
        override fun onFinalResult(hypothesis: String?) {}
        override fun onError(exception: Exception?) {
            Status.set("Ошибка: ${exception?.message}")
        }
        override fun onTimeout() {}
    }

    /** Возвращает индекс конца слова «Нова» в тексте или -1 */
    private fun findWakeEnd(t: String): Int {
        for (w in Config.WAKE_WORDS) {
            val m = Regex("(^|\\s)" + Regex.escape(w) + "(\\s|$)").find(t)
            if (m != null) return m.range.last + 1
        }
        return -1
    }

    private fun handleText(text: String) {
        if (text.isBlank()) return
        val t = text.lowercase().replace("ё", "е")
        val now = System.currentTimeMillis()

        val wakeEnd = findWakeEnd(t)
        val command: String? = when {
            wakeEnd >= 0 -> t.substring(minOf(wakeEnd, t.length)).trim()
            now < awakeUntil -> t
            else -> null
        }
        if (command == null) return

        Status.set("Распознано: $t")
        awakeUntil = 0

        val reply = if (command.isBlank()) {
            awakeUntil = now + Config.AWAKE_MS
            "Слушаю."
        } else {
            router.handle(command)
        }
        if (router.awaitingConfirm()) {
            awakeUntil = System.currentTimeMillis() + Config.CONFIRM_MS
        }
        if (reply.isNotBlank()) speaker?.say(reply)
    }

    override fun onDestroy() {
        main.removeCallbacksAndMessages(null)
        speech?.stop()
        speech?.shutdown()
        model?.close()
        speaker?.shutdown()
        Status.set("Остановлена")
        super.onDestroy()
    }
}

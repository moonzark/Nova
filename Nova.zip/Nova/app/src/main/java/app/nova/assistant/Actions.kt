package app.nova.assistant

import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager

object Actions {

    fun torch(ctx: Context, on: Boolean): Boolean {
        return try {
            val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return false
            cm.setTorchMode(id, on)
            true
        } catch (e: Exception) {
            false
        }
    }

    fun volume(ctx: Context, up: Boolean) {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        repeat(2) {
            am.adjustStreamVolume(
                AudioManager.STREAM_MUSIC,
                if (up) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER,
                AudioManager.FLAG_SHOW_UI
            )
        }
    }

    // Русские названия -> как приложение называется на телефоне
    private val aliases = mapOf(
        "ютуб" to "youtube", "ютюб" to "youtube",
        "телеграм" to "telegram", "телеграмм" to "telegram",
        "тикток" to "tiktok", "тик ток" to "tiktok",
        "ватсап" to "whatsapp", "вацап" to "whatsapp", "вотсап" to "whatsapp",
        "инстаграм" to "instagram", "инста" to "instagram",
        "дискорд" to "discord",
        "хром" to "chrome",
        "гугл" to "google",
        "почта" to "gmail",
        "карты" to "maps"
    )

    /** Возвращает (название, пакет) или null */
    fun findApp(ctx: Context, query: String): Pair<String, String>? {
        val q = query.trim()
        val target = aliases[q] ?: q
        val pm = ctx.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(intent, 0).map {
            it.loadLabel(pm).toString() to it.activityInfo.packageName
        }
        return apps
            .filter { it.first.lowercase().replace("ё", "е").contains(target) }
            .minByOrNull { it.first.length }
    }

    fun launch(ctx: Context, pkg: String): Boolean {
        val i = ctx.packageManager.getLaunchIntentForPackage(pkg) ?: return false
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val c: Context = NovaAccessibilityService.instance ?: ctx
        return try {
            c.startActivity(i)
            true
        } catch (e: Exception) {
            false
        }
    }
}

package app.nova.assistant

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class CommandRouter(private val ctx: Context) {

    private var pendingDeadline = 0L
    private var pendingAction: (() -> String)? = null

    fun awaitingConfirm(): Boolean =
        pendingAction != null && System.currentTimeMillis() < pendingDeadline

    private fun askConfirm(question: String, action: () -> String): String {
        pendingDeadline = System.currentTimeMillis() + Config.CONFIRM_MS
        pendingAction = action
        return question
    }

    /** Принимает уже очищенный текст команды (без слова «Астра»). Возвращает, что сказать. */
    fun handle(raw: String): String {
        val t = raw.lowercase().replace("ё", "е").trim()

        // Ответ на вопрос «Точно?»
        val pending = pendingAction
        if (pending != null) {
            pendingAction = null
            val yes = listOf("да", "подтверждаю", "давай", "выключай", "конечно")
            return if (System.currentTimeMillis() < pendingDeadline &&
                yes.any { t == it || t.startsWith("$it ") }
            ) pending() else "Отменено."
        }

        val a11y = NovaAccessibilityService.instance
        val needA11y = "Включи Спецвозможности для Nova в настройках телефона."

        return when {
            t.isBlank() -> "Слушаю."

            Regex("^(привет|здравствуй)").containsMatchIn(t) -> "Привет! Я ${Config.NAME}."

            t.contains("который час") || t.contains("сколько времени") ->
                "Сейчас " + SimpleDateFormat("H:mm", Locale("ru")).format(Date())

            t.contains("фонарик") -> {
                val off = t.contains("выключ") || t.contains("погаси") || t.contains("отключ")
                if (Actions.torch(ctx, !off)) {
                    if (off) "Фонарик выключен." else "Включаю фонарик."
                } else "Не получилось управлять фонариком."
            }

            t.contains("громче") || t.contains("прибавь") -> {
                Actions.volume(ctx, true); "Громче."
            }

            t.contains("тише") || t.contains("убавь") -> {
                Actions.volume(ctx, false); "Тише."
            }

            t.contains("выключи телефон") || t.contains("выключи смартфон") ||
                    t.contains("отключи телефон") || t.contains("выруби телефон") -> {
                if (a11y == null) needA11y
                else askConfirm("Точно выключить телефон? Скажи «да».") {
                    a11y.powerOff { ok ->
                        if (!ok) Status.set("Не нашёл кнопку выключения (смотри инструкцию)")
                    }
                    "Выключаю."
                }
            }

            t.contains("заблокируй") || t.contains("выключи экран") || t.contains("погаси экран") ->
                if (a11y == null) needA11y
                else if (a11y.lockScreen()) "Блокирую." else "Не получилось заблокировать."

            t.contains("скриншот") || t.contains("снимок экрана") ->
                if (a11y == null) needA11y
                else if (a11y.screenshot()) "Готово." else "Не получилось сделать скриншот."

            t == "назад" || t.contains("вернись") -> {
                if (a11y == null) needA11y else { a11y.back(); "Назад." }
            }

            t == "домой" || t.contains("главный экран") -> {
                if (a11y == null) needA11y else { a11y.home(); "Домой." }
            }

            t.contains("недавние") || t.contains("последние приложения") -> {
                if (a11y == null) needA11y else { a11y.recents(); "Вот недавние." }
            }

            Regex("^(открой|открыть|запусти|запустить)\\s+(.+)$").containsMatchIn(t) -> {
                val q = Regex("^(открой|открыть|запусти|запустить)\\s+(.+)$")
                    .find(t)!!.groupValues[2].trim()
                val app = Actions.findApp(ctx, q)
                when {
                    app == null -> "Приложение «$q» не найдено."
                    Actions.launch(ctx, app.second) -> "Открываю ${app.first}."
                    else -> "Не получилось открыть ${app.first}."
                }
            }

            t.contains("спасибо") -> "Всегда пожалуйста."
            t == "стоп" || t == "отмена" -> "Хорошо."

            else -> "Пока не умею: $t."
        }
    }
}

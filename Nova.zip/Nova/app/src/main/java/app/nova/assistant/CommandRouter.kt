package app.nova.assistant

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.AlarmClock
import android.view.KeyEvent
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.random.Random

class CommandRouter(
    private val ctx: Context,
    /** Для ответов, которые приходят позже (интернет): сказать вслух. */
    private val asyncReply: (String) -> Unit
) {

    private var pendingDeadline = 0L
    private var pendingAction: (() -> String)? = null

    fun awaitingConfirm(): Boolean =
        pendingAction != null && System.currentTimeMillis() < pendingDeadline

    private fun askConfirm(question: String, action: () -> String): String {
        pendingDeadline = System.currentTimeMillis() + Config.CONFIRM_MS
        pendingAction = action
        return question
    }

    /** Запускает работу в фоне (интернет). Ответ придёт через asyncReply. */
    private fun async(status: String, block: () -> String): String {
        Status.set(status)
        Thread {
            val r = try {
                block()
            } catch (e: AiError) {
                e.message ?: "ИИ сейчас не отвечает."
            } catch (e: java.io.IOException) {
                Status.set("Ошибка сети: ${e.message}")
                "Не получилось связаться с интернетом."
            } catch (e: Exception) {
                Status.set("Ошибка: ${e.message}")
                "Что-то пошло не так."
            }
            asyncReply(r)
        }.start()
        return ""
    }

    private fun clockText(h: Int, m: Int) = "$h:" + "%02d".format(m)

    private fun nextOccurrence(c: NumWords.Clk): Long {
        val hours = mutableListOf(c.hour)
        if (!c.hadModifier && c.hour in 1..11) hours.add(c.hour + 12)
        val now = System.currentTimeMillis()
        var best = Long.MAX_VALUE
        for (h in hours) {
            val cal = Calendar.getInstance()
            cal.set(Calendar.HOUR_OF_DAY, h)
            cal.set(Calendar.MINUTE, c.minute)
            cal.set(Calendar.SECOND, 0)
            cal.set(Calendar.MILLISECOND, 0)
            if (cal.timeInMillis <= now) cal.add(Calendar.DAY_OF_YEAR, 1)
            if (cal.timeInMillis < best) best = cal.timeInMillis
        }
        return best
    }

    private fun cleanReminderText(words: List<String>): String {
        val skip = setOf("про", "о", "об", "что", "чтобы", "насчет", "мне", "в", "на", "к")
        var i = 0
        while (i < words.size && words[i] in skip) i++
        val s = words.drop(i).joinToString(" ").trim()
        return if (s.isEmpty()) "это" else s
    }

    private fun setTimer(words: List<String>): String {
        val d = NumWords.duration(words)
            ?: return "На сколько поставить таймер? Скажи, например: таймер на пять минут."
        val sec = (d.millis / 1000).toInt().coerceAtLeast(1)
        val i = Intent(AlarmClock.ACTION_SET_TIMER)
            .putExtra(AlarmClock.EXTRA_LENGTH, sec)
            .putExtra(AlarmClock.EXTRA_MESSAGE, "Nova")
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        return if (Actions.start(ctx, i)) "Таймер на ${NumWords.spoken(d.millis)}."
        else "Не получилось поставить таймер."
    }

    private fun setAlarm(words: List<String>): String {
        val c = NumWords.clock(words)
            ?: return "На какое время? Скажи, например: будильник на семь тридцать."
        val i = Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, c.hour)
            .putExtra(AlarmClock.EXTRA_MINUTES, c.minute)
            .putExtra(AlarmClock.EXTRA_MESSAGE, "Nova")
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        return if (Actions.start(ctx, i)) "Будильник на ${clockText(c.hour, c.minute)}."
        else "Не получилось поставить будильник."
    }

    private fun remind(all: List<String>): String {
        val w = all.drop(1)
        val example = "Скажи, например: напомни через десять минут позвонить маме."
        val via = w.indexOf("через")
        if (via >= 0) {
            val rest = w.subList(via + 1, w.size)
            val d = NumWords.duration(rest)
            if (d != null) {
                val after = rest.subList(d.end, rest.size)
                val before = w.subList(0, via)
                val text = cleanReminderText(if (after.isNotEmpty()) after else before)
                Store.addReminder(ctx, System.currentTimeMillis() + d.millis, text)
                return "Хорошо, напомню через ${NumWords.spoken(d.millis)}: $text."
            }
        }
        val c = NumWords.clock(w) ?: return example
        val after = w.subList(minOf(c.end, w.size), w.size)
        val before = w.subList(0, c.start).filter { it !in setOf("в", "на", "к", "до") }
        val text = cleanReminderText(if (after.isNotEmpty()) after else before)
        val at = nextOccurrence(c)
        Store.addReminder(ctx, at, text)
        val cal = Calendar.getInstance().apply { timeInMillis = at }
        return "Хорошо, напомню в ${clockText(cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE))}: $text."
    }

    private fun listReminders(): String {
        val l = Store.upcoming(ctx)
        if (l.isEmpty()) return "Напоминаний нет."
        val fmt = SimpleDateFormat("H:mm", Locale("ru"))
        return "Напоминаний: ${l.size}. " +
                l.take(3).joinToString(". ") { "в ${fmt.format(Date(it.first))} — ${it.second}" }
    }

    /** Принимает уже очищенный текст команды (без слова «Нова»). Возвращает, что сказать. */
    fun handle(raw: String): String {
        val t = raw.lowercase().replace("ё", "е").trim()
        val words = t.split(Regex("\\s+")).filter { it.isNotEmpty() }

        // Ответ на вопрос «Точно?»
        val pending = pendingAction
        if (pending != null) {
            pendingAction = null
            val yes = listOf("да", "подтверждаю", "давай", "выключай", "конечно")
            return if (System.currentTimeMillis() < pendingDeadline &&
                yes.any { t == it || t.startsWith("$it ") }
            ) pending() else "Отменено."
        }

        val a11y = NovaAccessibilityService.instance
        val needA11y = "Включи Спецвозможности для Nova в настройках телефона."

        return when {
            t.isBlank() -> "Слушаю."

            Regex("^(привет|здравствуй)").containsMatchIn(t) -> "Привет! Я ${Config.NAME}."

            t.contains("который час") || t.contains("сколько времени") ->
                "Сейчас " + SimpleDateFormat("H:mm", Locale("ru")).format(Date())

            t.contains("какое сегодня число") || t.contains("какой сегодня день") ||
                    t.contains("какая сегодня дата") || t.contains("какое число") ||
                    t.contains("день недели") ->
                "Сегодня " + SimpleDateFormat("EEEE, d MMMM", Locale("ru")).format(Date())

            t.contains("заряд") || t.contains("батаре") || t.contains("сколько процентов") ->
                Actions.battery(ctx)

            words.any { it.startsWith("погод") && it != "погоди" } -> {
                val m = Regex("погод\\w*\\s+(?:в|во|для)\\s+(.+)$").find(t)
                val city = m?.groupValues?.get(1)
                    ?.replace(Regex("\\s+(сегодня|сейчас|завтра|на улице|там)$"), "")?.trim()
                async("Смотрю погоду…") { Weather.report(ctx, city) }
            }

            t.contains("таймер") -> setTimer(words)

            t.contains("будильник") || words.firstOrNull()?.startsWith("разбуди") == true ->
                setAlarm(words)

            t.contains("напоминани") &&
                    (t.contains("какие") || t.contains("мои") || t.contains("покажи") || t.contains("список")) ->
                listReminders()

            Regex("^напомн").containsMatchIn(t) -> remind(words)

            Regex("^запомни\\w*\\s+(?:что\\s+)?(.+)$").containsMatchIn(t) -> {
                val note = Regex("^запомни\\w*\\s+(?:что\\s+)?(.+)$").find(t)!!.groupValues[1]
                Store.addNote(ctx, note)
                "Запомнила."
            }

            t.contains("что ты помнишь") || t.contains("что ты запомнила") ||
                    t.contains("что ты запомнил") -> {
                val n = Store.notes(ctx)
                if (n.isEmpty()) "Пока ничего не помню." else "Помню: " + n.takeLast(5).joinToString(". ")
            }

            t.contains("забудь все") || t.contains("очисти память") -> {
                Store.clearMemory(ctx); "Всё забыла."
            }

            Regex("^(найди|поищи|загугли|погугли)\\s+(.+)$").containsMatchIn(t) -> {
                val q = Regex("^(найди|поищи|загугли|погугли)\\s+(.+)$").find(t)!!.groupValues[2]
                val ytRe = Regex("\\s*(в|на)\\s+(ютубе|ютюбе|youtube)\\s*")
                val yt = ytRe.containsMatchIn(q)
                val clean = q.replace(ytRe, " ").trim()
                val enc = URLEncoder.encode(clean, "UTF-8")
                val url = if (yt) "https://www.youtube.com/results?search_query=$enc"
                else "https://www.google.com/search?q=$enc"
                if (Actions.start(ctx, Intent(Intent.ACTION_VIEW, Uri.parse(url)))) "Ищу: $clean."
                else "Не получилось открыть поиск."
            }

            Regex("^(позвони|набери|вызови)\\s+(.+)$").containsMatchIn(t) -> {
                val name = Regex("^(позвони|набери|вызови)\\s+(.+)$").find(t)!!.groupValues[2]
                Actions.call(ctx, name)
            }

            t == "пауза" || t.contains("на паузу") || t.contains("останови музыку") -> {
                Actions.media(ctx, KeyEvent.KEYCODE_MEDIA_PAUSE); "Пауза."
            }

            t.contains("продолжи") || t.contains("воспроизведи") || t.contains("включи музыку") ||
                    t == "играй" -> {
                Actions.media(ctx, KeyEvent.KEYCODE_MEDIA_PLAY); "Играю."
            }

            t.contains("следующ") || t == "дальше" || t.contains("переключи") -> {
                Actions.media(ctx, KeyEvent.KEYCODE_MEDIA_NEXT); "Дальше."
            }

            t.contains("предыдущ") || t.contains("прошлый трек") -> {
                Actions.media(ctx, KeyEvent.KEYCODE_MEDIA_PREVIOUS); "Назад по трекам."
            }

            t.contains("монет") || t.contains("орел или решка") ->
                if (Random.nextBoolean()) "Орёл." else "Решка."

            t.contains("кубик") || t.contains("брось кость") ->
                "Выпало ${Random.nextInt(1, 7)}."

            t.contains("фонарик") -> {
                val off = t.contains("выключ") || t.contains("погаси") || t.contains("отключ")
                if (Actions.torch(ctx, !off)) {
                    if (off) "Фонарик выключен." else "Включаю фонарик."
                } else "Не получилось управлять фонариком."
            }

            t.contains("громче") || t.contains("прибавь") -> {
                Actions.volume(ctx, true); "Громче."
            }

            t.contains("тише") || t.contains("убавь") -> {
                Actions.volume(ctx, false); "Тише."
            }

            t.contains("выключи телефон") || t.contains("выключи смартфон") ||
                    t.contains("отключи телефон") || t.contains("выруби телефон") -> {
                if (a11y == null) needA11y
                else askConfirm("Точно выключить телефон? Скажи «да».") {
                    a11y.powerOff { ok ->
                        if (!ok) Status.set("Не нашёл кнопку выключения (смотри инструкцию)")
                    }
                    "Выключаю."
                }
            }

            t.contains("заблокируй") || t.contains("выключи экран") || t.contains("погаси экран") ->
                if (a11y == null) needA11y
                else if (a11y.lockScreen()) "Блокирую." else "Не получилось заблокировать."

            t.contains("скриншот") || t.contains("снимок экрана") ->
                if (a11y == null) needA11y
                else if (a11y.screenshot()) "Готово." else "Не получилось сделать скриншот."

            t == "назад" || t.contains("вернись") -> {
                if (a11y == null) needA11y else { a11y.back(); "Назад." }
            }

            t == "домой" || t.contains("главный экран") -> {
                if (a11y == null) needA11y else { a11y.home(); "Домой." }
            }

            t.contains("недавние") || t.contains("последние приложения") -> {
                if (a11y == null) needA11y else { a11y.recents(); "Вот недавние." }
            }

            Regex("^(открой|открыть|запусти|запустить)\\s+(.+)$").containsMatchIn(t) -> {
                val q = Regex("^(открой|открыть|запусти|запустить)\\s+(.+)$")
                    .find(t)!!.groupValues[2].trim()
                val app = Actions.findApp(ctx, q)
                when {
                    app == null -> "Приложение «$q» не найдено."
                    Actions.launch(ctx, app.second) -> "Открываю ${app.first}."
                    else -> "Не получилось открыть ${app.first}."
                }
            }

            t.contains("спасибо") -> "Всегда пожалуйста."
            t == "стоп" || t == "отмена" -> "Хорошо."

            else -> {
                if (Store.apiKey(ctx).isBlank()) {
                    "Пока не умею: $t. Добавь ключ ИИ в настройках приложения, и я смогу отвечать на любые вопросы."
                } else {
                    async("Думаю…") { Ai.ask(ctx, t) }
                }
            }
        }
    }
}

package app.nova.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Настройки и память Новы (хранится только на телефоне). */
object Store {
    private fun p(ctx: Context) =
        ctx.applicationContext.getSharedPreferences("nova", Context.MODE_PRIVATE)

    private fun maxAge(): Long = Config.MEMORY_HOURS * 3_600_000L

    fun apiKey(ctx: Context): String = p(ctx).getString("api_key", "")?.trim() ?: ""
    fun setApiKey(ctx: Context, v: String) { p(ctx).edit().putString("api_key", v.trim()).apply() }
    fun city(ctx: Context): String = p(ctx).getString("city", "")?.trim() ?: ""
    fun setCity(ctx: Context, v: String) { p(ctx).edit().putString("city", v.trim()).apply() }

    fun googleStt(ctx: Context): Boolean = p(ctx).getBoolean("google_stt", true)
    fun setGoogleStt(ctx: Context, v: Boolean) { p(ctx).edit().putBoolean("google_stt", v).apply() }
    fun voiceName(ctx: Context): String = p(ctx).getString("voice", "") ?: ""
    fun setVoiceName(ctx: Context, v: String) { p(ctx).edit().putString("voice", v).apply() }
    fun pitch(ctx: Context): Float = p(ctx).getFloat("pitch", Config.TTS_PITCH)
    fun setPitch(ctx: Context, v: Float) { p(ctx).edit().putFloat("pitch", v).apply() }
    fun rate(ctx: Context): Float = p(ctx).getFloat("rate", Config.TTS_RATE)
    fun setRate(ctx: Context, v: Float) { p(ctx).edit().putFloat("rate", v).apply() }

    private fun load(ctx: Context, key: String): MutableList<JSONObject> {
        val out = mutableListOf<JSONObject>()
        try {
            val a = JSONArray(p(ctx).getString(key, "[]") ?: "[]")
            for (i in 0 until a.length()) out.add(a.getJSONObject(i))
        } catch (e: Exception) {
        }
        return out
    }

    private fun save(ctx: Context, key: String, list: List<JSONObject>) {
        val a = JSONArray()
        for (o in list) a.put(o)
        p(ctx).edit().putString(key, a.toString()).apply()
    }

    private fun fresh(list: List<JSONObject>): MutableList<JSONObject> {
        val now = System.currentTimeMillis()
        return list.filter { now - it.optLong("t") < maxAge() }.toMutableList()
    }

    // ---------- Разговор (помним 72 часа) ----------
    @Synchronized
    fun addHistory(ctx: Context, role: String, text: String) {
        val l = fresh(load(ctx, "history"))
        l.add(JSONObject().put("t", System.currentTimeMillis()).put("r", role).put("x", text))
        save(ctx, "history", l.takeLast(40))
    }

    @Synchronized
    fun history(ctx: Context, max: Int): List<Pair<String, String>> =
        fresh(load(ctx, "history")).takeLast(max).map { it.optString("r") to it.optString("x") }

    // ---------- «Запомни…» ----------
    @Synchronized
    fun addNote(ctx: Context, text: String) {
        val l = fresh(load(ctx, "notes"))
        l.add(JSONObject().put("t", System.currentTimeMillis()).put("x", text))
        save(ctx, "notes", l.takeLast(50))
    }

    @Synchronized
    fun notes(ctx: Context): List<String> = fresh(load(ctx, "notes")).map { it.optString("x") }

    @Synchronized
    fun clearMemory(ctx: Context) {
        p(ctx).edit().remove("history").remove("notes").apply()
    }

    // ---------- Напоминания ----------
    @Synchronized
    fun addReminder(ctx: Context, at: Long, text: String) {
        val l = load(ctx, "reminders")
        l.add(JSONObject().put("at", at).put("x", text))
        save(ctx, "reminders", l)
    }

    @Synchronized
    fun upcoming(ctx: Context): List<Pair<Long, String>> =
        load(ctx, "reminders").map { it.optLong("at") to it.optString("x") }.sortedBy { it.first }

    /** Возвращает тексты сработавших напоминаний и удаляет их. */
    @Synchronized
    fun takeDue(ctx: Context): List<String> {
        val now = System.currentTimeMillis()
        val l = load(ctx, "reminders")
        if (l.isEmpty()) return emptyList()
        val due = l.filter { it.optLong("at") <= now }
        if (due.isEmpty()) return emptyList()
        save(ctx, "reminders", l.filter { it.optLong("at") > now })
        return due.map { it.optString("x") }
    }
}

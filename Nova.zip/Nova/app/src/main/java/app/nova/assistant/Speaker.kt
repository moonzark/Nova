package app.nova.assistant

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import java.util.Locale

class Speaker(
    ctx: Context,
    private val onSpeakStart: () -> Unit,
    private val onSpeakEnd: () -> Unit
) {
    private val app: Context = ctx.applicationContext
    private var ready = false
    private var tts: TextToSpeech? = null
    private var appliedVoice: String? = null

    companion object {
        /** Русские голоса, лучшие по качеству первыми. */
        fun russianVoices(t: TextToSpeech): List<Voice> = try {
            (t.voices ?: emptySet<Voice>())
                .filter { it.locale.language == "ru" }
                .sortedWith(compareByDescending<Voice> { it.quality }.thenBy { it.name })
        } catch (e: Exception) {
            emptyList()
        }
    }

    init {
        tts = TextToSpeech(app) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val r = tts?.setLanguage(Locale("ru", "RU"))
                ready = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) { onSpeakEnd() }
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) { onSpeakEnd() }
                })
            }
        }
    }

    private fun applyVoice(t: TextToSpeech) {
        t.setPitch(Store.pitch(app))
        t.setSpeechRate(Store.rate(app))
        val name = Store.voiceName(app)
        if (name.isNotEmpty() && name != appliedVoice) {
            val v = try { t.voices?.firstOrNull { it.name == name } } catch (e: Exception) { null }
            if (v != null) {
                t.setVoice(v)
                appliedVoice = name
            }
        }
    }

    fun say(text: String) {
        val t = tts
        if (!ready || t == null) {
            onSpeakEnd()
            return
        }
        applyVoice(t)
        onSpeakStart()
        val r = t.speak(text, TextToSpeech.QUEUE_FLUSH, null, "nova-" + System.nanoTime())
        if (r != TextToSpeech.SUCCESS) onSpeakEnd()
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
    }
}

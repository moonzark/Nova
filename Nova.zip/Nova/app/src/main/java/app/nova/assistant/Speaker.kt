package app.nova.assistant

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

class Speaker(
    ctx: Context,
    private val onSpeakStart: () -> Unit,
    private val onSpeakEnd: () -> Unit
) {
    private var ready = false
    private var tts: TextToSpeech? = null

    init {
        tts = TextToSpeech(ctx.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val r = tts?.setLanguage(Locale("ru", "RU"))
                ready = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED
                tts?.setPitch(Config.TTS_PITCH)
                tts?.setSpeechRate(Config.TTS_RATE)
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) { onSpeakEnd() }
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) { onSpeakEnd() }
                })
            }
        }
    }

    fun say(text: String) {
        if (!ready) return
        onSpeakStart()
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "nova-" + System.nanoTime())
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
    }
}

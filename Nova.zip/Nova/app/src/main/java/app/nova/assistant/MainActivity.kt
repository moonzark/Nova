package app.nova.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var statusView: TextView
    private lateinit var a11yView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (20 * resources.displayMetrics.density).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
            setBackgroundColor(Color.parseColor("#050B1F"))
        }

        fun label(text: String, size: Float, color: String, bold: Boolean = false): TextView =
            TextView(this).apply {
                this.text = text
                textSize = size
                setTextColor(Color.parseColor(color))
                if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
                setPadding(0, pad / 3, 0, pad / 3)
            }

        fun button(text: String, onClick: () -> Unit): Button =
            Button(this).apply {
                this.text = text
                isAllCaps = false
                setOnClickListener { onClick() }
            }

        root.addView(label("N O V A", 28f, "#7DB7FF", true).apply { gravity = Gravity.CENTER })
        root.addView(label("Голосовой ассистент. Слово активации: «Нова»", 14f, "#9FB3D9"))

        statusView = label(Status.text, 16f, "#FFFFFF", true)
        a11yView = label("", 14f, "#9FB3D9")
        root.addView(statusView)
        root.addView(a11yView)

        root.addView(label("Настройка (сделай по порядку):", 15f, "#7DB7FF", true))

        root.addView(button("1. Дать доступ (микрофон, контакты, звонки, уведомления)") {
            val perms = mutableListOf(
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.READ_CONTACTS,
                Manifest.permission.CALL_PHONE
            )
            if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
            requestPermissions(perms.toTypedArray(), 1)
        })
        root.addView(button("2. Включить Спецвозможности (найди Nova)") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        root.addView(button("3. Разрешить показ поверх других приложений") {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        })
        root.addView(button("4. Без ограничений батареи (найди Nova)") {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        })
        root.addView(button("5. ЗАПУСТИТЬ Nova") {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Сначала шаг 1", Toast.LENGTH_SHORT).show()
            } else {
                startForegroundService(Intent(this, AssistantService::class.java))
            }
        })
        root.addView(button("Остановить") {
            stopService(Intent(this, AssistantService::class.java))
        })

        root.addView(label("Умный режим (бесплатный ИИ) и погода:", 15f, "#7DB7FF", true))
        root.addView(
            label(
                "Ключ Groq (начинается с gsk_) берётся на console.groq.com/keys, " +
                        "ключ Gemini (начинается с AIza) — в Google AI Studio. Хранится только на этом телефоне.",
                12f, "#9FB3D9"
            )
        )

        fun input(hintText: String, value: String): EditText =
            EditText(this).apply {
                hint = hintText
                setText(value)
                setTextColor(Color.WHITE)
                setHintTextColor(Color.parseColor("#6B7FA8"))
                isSingleLine = true
                inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            }

        val keyInput = input("Ключ ИИ (gsk_… или AIza…)", Store.apiKey(this))
        val cityInput = input("Город по умолчанию для погоды", Store.city(this))
        root.addView(keyInput)
        root.addView(cityInput)
        root.addView(button("Сохранить настройки") {
            Store.setApiKey(this, keyInput.text.toString())
            Store.setCity(this, cityInput.text.toString())
            Toast.makeText(this, "Сохранено", Toast.LENGTH_SHORT).show()
        })

        root.addView(label("Попробуй сказать:", 15f, "#7DB7FF", true))
        root.addView(
            label(
                "• Нова, который час / какое сегодня число\n" +
                        "• Нова, какая погода (или: погода в Лондоне)\n" +
                        "• Нова, любой вопрос — ответит ИИ (нужен ключ)\n" +
                        "• Нова, таймер на пять минут\n" +
                        "• Нова, разбуди меня в семь тридцать\n" +
                        "• Нова, напомни через десять минут позвонить маме\n" +
                        "• Нова, запомни что ... / что ты помнишь / забудь всё\n" +
                        "• Нова, позвони маме\n" +
                        "• Нова, найди ... / найди в ютубе ...\n" +
                        "• Нова, пауза / продолжи / следующий трек\n" +
                        "• Нова, сколько заряда\n" +
                        "• Нова, открой ютуб / включи фонарик\n" +
                        "• Нова, громче / тише / скриншот / домой / назад\n" +
                        "• Нова, заблокируй экран\n" +
                        "• Нова, выключи телефон (спросит «да»)\n" +
                        "• Нова, брось монетку / кубик",
                14f, "#D5E2FF"
            )
        )

        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        refresh()
        Status.onChange = { statusView.text = it }
    }

    override fun onPause() {
        Status.onChange = null
        super.onPause()
    }

    private fun refresh() {
        statusView.text = Status.text
        a11yView.text = if (NovaAccessibilityService.instance != null)
            "Спецвозможности: включены ✓" else "Спецвозможности: выключены ✗"
    }
}

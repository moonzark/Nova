package app.nova.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

class MainActivity : Activity() {

    private lateinit var statusView: TextView
    private lateinit var a11yView: TextView
    private lateinit var voiceLabel: TextView

    private var tts: TextToSpeech? = null
    private var voices: List<Voice> = emptyList()
    private val sample = "Привет! Я Нова. Как тебе мой голос?"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val ctx = this
        val dm = resources.displayMetrics
        fun dp(v: Int): Int = (v * dm.density).toInt()
        val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
        val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.parseColor("#050814")

        // ---------- фон ----------
        val bg = ImageView(ctx).apply {
            setImageResource(R.drawable.bg_space)
            scaleType = ImageView.ScaleType.CENTER_CROP
        }
        val scrim = View(ctx).apply { setBackgroundColor(Color.parseColor("#8C030814")) }

        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(36), dp(16), dp(28))
        }

        fun label(text: String, size: Float, color: String, bold: Boolean = false): TextView =
            TextView(ctx).apply {
                this.text = text
                textSize = size
                setTextColor(Color.parseColor(color))
                if (bold) setTypeface(typeface, Typeface.BOLD)
                setPadding(0, dp(3), 0, dp(3))
            }

        fun styledButton(text: String, primary: Boolean = false, onClick: () -> Unit): Button =
            Button(ctx).apply {
                this.text = text
                isAllCaps = false
                textSize = 15f
                setTextColor(Color.WHITE)
                minHeight = dp(52)
                minimumHeight = dp(52)
                val shape = GradientDrawable(
                    GradientDrawable.Orientation.LEFT_RIGHT,
                    if (primary) intArrayOf(Color.parseColor("#8A5BFF"), Color.parseColor("#2E7BFF"))
                    else intArrayOf(Color.parseColor("#26305E"), Color.parseColor("#1B2447"))
                ).apply {
                    cornerRadius = dp(26).toFloat()
                    if (!primary) setStroke(dp(1), Color.parseColor("#4C6FFF"))
                }
                background = RippleDrawable(ColorStateList.valueOf(Color.parseColor("#44FFFFFF")), shape, null)
                setOnClickListener { onClick() }
                layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) }
            }

        fun card(title: String?, build: LinearLayout.() -> Unit) {
            val c = LinearLayout(ctx).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(16), dp(14), dp(16), dp(16))
                background = GradientDrawable().apply {
                    setColor(Color.parseColor("#B3101A38"))
                    cornerRadius = dp(22).toFloat()
                    setStroke(dp(1), Color.parseColor("#335B7CFF"))
                }
            }
            if (title != null) c.addView(label(title, 15f, "#8FB4FF", true))
            c.build()
            root.addView(c, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(12) })
        }

        fun input(hintText: String, value: String): EditText =
            EditText(ctx).apply {
                hint = hintText
                setText(value)
                setTextColor(Color.WHITE)
                setHintTextColor(Color.parseColor("#6B7FA8"))
                isSingleLine = true
                inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            }

        // ---------- шапка с картинкой ----------
        val heroW = dm.widthPixels - dp(32)
        val heroH = (heroW * 413f / 735f).toInt()
        val hero = FrameLayout(ctx)
        hero.addView(
            ImageView(ctx).apply {
                setImageResource(R.drawable.hero)
                scaleType = ImageView.ScaleType.CENTER_CROP
            },
            FrameLayout.LayoutParams(MATCH, MATCH)
        )
        hero.addView(
            TextView(ctx).apply {
                text = "N O V A"
                textSize = 30f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(Color.WHITE)
                setShadowLayer(12f, 0f, 0f, Color.parseColor("#7C9DFF"))
                setPadding(dp(18), 0, 0, dp(14))
            },
            FrameLayout.LayoutParams(WRAP, WRAP, Gravity.BOTTOM or Gravity.START)
        )
        hero.clipToOutline = true
        hero.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, dp(24).toFloat())
            }
        }
        root.addView(hero, LinearLayout.LayoutParams(MATCH, heroH))

        // ---------- статус ----------
        statusView = label(Status.text, 17f, "#FFFFFF", true)
        a11yView = label("", 13f, "#9FB3D9")
        card(null) {
            addView(label("Голосовой ассистент. Скажи «Нова» и команду", 13f, "#9FB3D9"))
            addView(statusView)
            addView(a11yView)
        }

        // ---------- настройка ----------
        card("Настройка (по порядку)") {
            addView(styledButton("1. Дать доступы (микрофон, контакты, звонки)") {
                val perms = mutableListOf(
                    Manifest.permission.RECORD_AUDIO,
                    Manifest.permission.READ_CONTACTS,
                    Manifest.permission.CALL_PHONE
                )
                if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
                requestPermissions(perms.toTypedArray(), 1)
            })
            addView(styledButton("2. Включить Спецвозможности (найди Nova)") {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            })
            addView(styledButton("3. Разрешить показ поверх других приложений") {
                startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                )
            })
            addView(styledButton("4. Без ограничений батареи (найди Nova)") {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            })
            addView(styledButton("5. ЗАПУСТИТЬ Nova", primary = true) {
                if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(ctx, "Сначала шаг 1", Toast.LENGTH_SHORT).show()
                } else {
                    startForegroundService(Intent(ctx, AssistantService::class.java))
                }
            })
            addView(styledButton("Остановить") {
                stopService(Intent(ctx, AssistantService::class.java))
            })
        }

        // ---------- ИИ и погода ----------
        val keyInput = input("Ключ ИИ (gsk_… или AIza…)", Store.apiKey(ctx))
        val cityInput = input("Город по умолчанию для погоды", Store.city(ctx))
        val answerView = label("", 14f, "#D5E2FF").apply { setTextIsSelectable(true) }
        val chatInput = input("Напиши вопрос Нове…", "")

        card("Умный режим (бесплатный ИИ)") {
            addView(
                label(
                    "Ключ Groq (gsk_…) берётся на console.groq.com/keys. " +
                            "Хранится только на этом телефоне.",
                    12f, "#9FB3D9"
                )
            )
            addView(keyInput)
            addView(cityInput)
            addView(styledButton("Сохранить настройки") {
                Store.setApiKey(ctx, keyInput.text.toString())
                Store.setCity(ctx, cityInput.text.toString())
                Toast.makeText(ctx, "Сохранено", Toast.LENGTH_SHORT).show()
            })
        }

        card("Чат с Новой (проверка ИИ)") {
            addView(chatInput)
            addView(styledButton("Спросить", primary = true) {
                Store.setApiKey(ctx, keyInput.text.toString())
                Store.setCity(ctx, cityInput.text.toString())
                val q = chatInput.text.toString().trim()
                if (q.isEmpty()) {
                    answerView.text = "Напиши вопрос в поле выше."
                } else if (Store.apiKey(ctx).isBlank()) {
                    answerView.text = "Сначала впиши ключ ИИ в поле выше."
                } else {
                    answerView.text = "Думаю…"
                    Thread {
                        val res = try {
                            Ai.ask(ctx, q)
                        } catch (e: AiError) {
                            "Ошибка: ${e.message}\n(${Status.text})"
                        } catch (e: Exception) {
                            "Ошибка: ${e.javaClass.simpleName}: ${e.message}"
                        }
                        runOnUiThread { answerView.text = res }
                    }.start()
                }
            })
            addView(answerView)
        }

        // ---------- голос ----------
        voiceLabel = label("Голос: загрузка…", 13f, "#D5E2FF")
        fun speakSample() {
            val t = tts ?: return
            t.setPitch(Store.pitch(ctx))
            t.setSpeechRate(Store.rate(ctx))
            t.speak(sample, TextToSpeech.QUEUE_FLUSH, null, "sample")
        }

        fun seek(title: String, from: Float, to: Float, current: Float, onChange: (Float) -> Unit): LinearLayout {
            val box = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
            box.addView(label(title, 13f, "#9FB3D9"))
            val bar = SeekBar(ctx).apply {
                max = 100
                progress = (((current - from) / (to - from)) * 100).toInt().coerceIn(0, 100)
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                        if (fromUser) onChange(from + (to - from) * p / 100f)
                    }
                    override fun onStartTrackingTouch(sb: SeekBar?) {}
                    override fun onStopTrackingTouch(sb: SeekBar?) { speakSample() }
                })
            }
            box.addView(bar)
            return box
        }

        card("Голос Новы") {
            addView(voiceLabel)
            addView(styledButton("Сменить голос (нажимай, пока не понравится)") {
                val t = tts
                if (t == null || voices.isEmpty()) {
                    Toast.makeText(
                        ctx, "Русских голосов не найдено. Установи голос в настройках «Синтез речи».",
                        Toast.LENGTH_LONG
                    ).show()
                } else {
                    val cur = voices.indexOfFirst { it.name == Store.voiceName(ctx) }
                    val next = voices[(cur + 1) % voices.size]
                    Store.setVoiceName(ctx, next.name)
                    t.setVoice(next)
                    updateVoiceLabel()
                    speakSample()
                }
            })
            addView(seek("Тон голоса (выше = мило)", 0.6f, 1.8f, Store.pitch(ctx)) { Store.setPitch(ctx, it) })
            addView(seek("Скорость речи", 0.6f, 1.6f, Store.rate(ctx)) { Store.setRate(ctx, it) })
        }

        // ---------- распознавание ----------
        card("Распознавание команд") {
            lateinit var btn: Button
            fun text() = if (Store.googleStt(ctx)) "Через Google (точнее): ВКЛ" else "Офлайн Vosk (хуже): ВКЛ"
            btn = styledButton(text()) {
                Store.setGoogleStt(ctx, !Store.googleStt(ctx))
                btn.text = text()
                Toast.makeText(ctx, "Нажми «Остановить», потом «ЗАПУСТИТЬ»", Toast.LENGTH_LONG).show()
            }
            addView(
                label(
                    "Google-режим: скажи «Нова», дождись короткого сигнала и говори команду. " +
                            "Нужен интернет.",
                    12f, "#9FB3D9"
                )
            )
            addView(btn)
        }

        card("Что можно сказать") {
            addView(
                label(
                    "• Нова, который час / какое сегодня число\n" +
                            "• Нова, какая погода (или: погода в Лондоне)\n" +
                            "• Нова, любой вопрос — ответит ИИ\n" +
                            "• Нова, открой инстаграм (ИИ сам найдёт приложение)\n" +
                            "• Нова, таймер на пять минут\n" +
                            "• Нова, разбуди меня в семь тридцать\n" +
                            "• Нова, напомни через десять минут позвонить маме\n" +
                            "• Нова, запомни что ... / что ты помнишь / забудь всё\n" +
                            "• Нова, позвони маме\n" +
                            "• Нова, найди ... / найди в ютубе ...\n" +
                            "• Нова, пауза / продолжи / следующий трек\n" +
                            "• Нова, сколько заряда\n" +
                            "• Нова, включи фонарик / громче / тише\n" +
                            "• Нова, скриншот / домой / назад / заблокируй экран\n" +
                            "• Нова, выключи телефон (спросит «да»)\n" +
                            "• Нова, брось монетку / кубик",
                    13f, "#D5E2FF"
                )
            )
        }

        setContentView(FrameLayout(ctx).apply {
            addView(bg, FrameLayout.LayoutParams(MATCH, MATCH))
            addView(scrim, FrameLayout.LayoutParams(MATCH, MATCH))
            addView(ScrollView(ctx).apply { addView(root) }, FrameLayout.LayoutParams(MATCH, MATCH))
        })

        // движок голоса для проверки
        tts = TextToSpeech(ctx) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.setLanguage(Locale("ru", "RU"))
                tts?.let { t ->
                    voices = Speaker.russianVoices(t)
                    val saved = voices.firstOrNull { it.name == Store.voiceName(ctx) }
                    if (saved != null) t.setVoice(saved)
                }
                updateVoiceLabel()
            } else {
                voiceLabel.text = "Голос: движок речи недоступен"
            }
        }
    }

    private fun updateVoiceLabel() {
        val idx = voices.indexOfFirst { it.name == Store.voiceName(this) }
        voiceLabel.text = when {
            voices.isEmpty() -> "Голос: русских голосов не найдено"
            idx < 0 -> "Голос: по умолчанию (всего голосов: ${voices.size})"
            else -> "Голос ${idx + 1} из ${voices.size}: ${voices[idx].name}"
        }
    }

    override fun onResume() {
        super.onResume()
        refresh()
        Status.onChange = { statusView.text = it }
    }

    override fun onPause() {
        Status.onChange = null
        super.onPause()
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }

    private fun refresh() {
        statusView.text = Status.text
        a11yView.text = if (NovaAccessibilityService.instance != null)
            "Спецвозможности: включены ✓" else "Спецвозможности: выключены ✗"
    }
}

package app.nova.assistant

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.Uri
import android.os.BatteryManager
import android.provider.ContactsContract
import android.view.KeyEvent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager

object Actions {

    fun torch(ctx: Context, on: Boolean): Boolean {
        return try {
            val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return false
            cm.setTorchMode(id, on)
            true
        } catch (e: Exception) {
            false
        }
    }

    fun volume(ctx: Context, up: Boolean) {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        repeat(2) {
            am.adjustStreamVolume(
                AudioManager.STREAM_MUSIC,
                if (up) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER,
                AudioManager.FLAG_SHOW_UI
            )
        }
    }

    // Русские названия -> как приложение называется на телефоне
    private val aliases = mapOf(
        "ютуб" to "youtube", "ютюб" to "youtube",
        "телеграм" to "telegram", "телеграмм" to "telegram",
        "тикток" to "tiktok", "тик ток" to "tiktok",
        "ватсап" to "whatsapp", "вацап" to "whatsapp", "вотсап" to "whatsapp",
        "инстаграм" to "instagram", "инста" to "instagram",
        "дискорд" to "discord",
        "хром" to "chrome",
        "гугл" to "google",
        "почта" to "gmail",
        "карты" to "maps"
    )

    /** Возвращает (название, пакет) или null */
    /** Все приложения с иконкой запуска: (название, пакет). */
    fun allApps(ctx: Context): List<Pair<String, String>> {
        val pm = ctx.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(intent, 0)
            .map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
            .distinctBy { it.second }
    }

    fun findApp(ctx: Context, query: String): Pair<String, String>? {
        val q = query.trim().lowercase().replace("ё", "е")
        val target = aliases[q] ?: q
        return allApps(ctx)
            .filter { it.first.lowercase().replace("ё", "е").contains(target) }
            .minByOrNull { it.first.length }
    }

    /** Запуск экрана/приложения (через Спецвозможности, чтобы работало из фона). */
    fun start(ctx: Context, i: Intent): Boolean {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val c: Context = NovaAccessibilityService.instance ?: ctx
        return try {
            c.startActivity(i)
            true
        } catch (e: Exception) {
            false
        }
    }

    fun launch(ctx: Context, pkg: String): Boolean {
        val i = ctx.packageManager.getLaunchIntentForPackage(pkg) ?: return false
        return start(ctx, i)
    }

    fun media(ctx: Context, keyCode: Int) {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, keyCode))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, keyCode))
    }

    fun battery(ctx: Context): String {
        val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val pct = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val st = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            ?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val charging = st == BatteryManager.BATTERY_STATUS_CHARGING ||
                st == BatteryManager.BATTERY_STATUS_FULL
        val word = NumWords.plural(pct, "процент", "процента", "процентов")
        return "Заряд $pct $word" + if (charging) ", телефон заряжается." else "."
    }

    fun call(ctx: Context, spoken: String): String {
        val ok = ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED &&
                ctx.checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
        if (!ok) return "Нужен доступ к контактам и звонкам. Нажми кнопку 1 в приложении ещё раз."

        val q = spoken.lowercase().replace("ё", "е").trim()
        if (q.isEmpty()) return "Кому позвонить?"
        // «маме» -> «мам», чтобы найти контакт «Мама»
        val stem = if (q.length > 3) q.dropLast(1) else q

        var bestName: String? = null
        var bestNumber: String? = null
        ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            ),
            null, null, null
        )?.use { c ->
            while (c.moveToNext()) {
                val name = c.getString(0) ?: continue
                val number = c.getString(1) ?: continue
                if (name.lowercase().replace("ё", "е").contains(stem)) {
                    if (bestName == null || name.length < bestName!!.length) {
                        bestName = name
                        bestNumber = number
                    }
                }
            }
        }
        val n = bestNumber
        val nm = bestName
        if (n == null || nm == null) return "Не нашла контакт $spoken."
        val i = Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(n)))
        return if (start(ctx, i)) "Звоню: $nm." else "Не получилось позвонить."
    }
}

package app.nova.assistant

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** Погода через Open-Meteo (бесплатно, без ключа). */
object Weather {
    private class Place(val name: String, val lat: Double, val lon: Double)

    private fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 10_000
            c.readTimeout = 15_000
            c.setRequestProperty("User-Agent", "Nova-Android/0.2")
            val code = c.responseCode
            if (code !in 200..299) throw java.io.IOException("HTTP $code")
            return c.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    private fun geocode(q: String): Place? {
        // Город из речи бывает в падеже («в Москве»), поэтому пробуем с отрезанным окончанием
        val variants = linkedSetOf(
            q,
            if (q.length > 3) q.dropLast(1) else q,
            if (q.length > 4) q.dropLast(2) else q
        )
        for (v in variants) {
            val url = "https://geocoding-api.open-meteo.com/v1/search?name=" +
                    URLEncoder.encode(v, "UTF-8") + "&count=1&language=ru&format=json"
            val arr = JSONObject(get(url)).optJSONArray("results") ?: continue
            if (arr.length() == 0) continue
            val o = arr.getJSONObject(0)
            return Place(o.optString("name", v), o.getDouble("latitude"), o.getDouble("longitude"))
        }
        return null
    }

    private fun describe(code: Int): String = when (code) {
        0 -> "ясно"
        1 -> "преимущественно ясно"
        2 -> "переменная облачность"
        3 -> "пасмурно"
        45, 48 -> "туман"
        51, 53, 55, 56, 57 -> "морось"
        61 -> "небольшой дождь"
        63 -> "дождь"
        65 -> "сильный дождь"
        66, 67 -> "ледяной дождь"
        71 -> "небольшой снег"
        73 -> "снег"
        75 -> "сильный снег"
        77 -> "снежная крупа"
        80, 81, 82 -> "ливень"
        85, 86 -> "снегопад"
        95 -> "гроза"
        96, 99 -> "гроза с градом"
        else -> "облачно"
    }

    private fun deg(x: Double): String {
        val r = Math.round(x).toInt()
        return when {
            r > 0 -> "плюс $r"
            r < 0 -> "минус ${-r}"
            else -> "ноль"
        }
    }

    fun report(ctx: Context, cityIn: String?): String {
        var q = (cityIn ?: "").trim()
        if (q.isEmpty()) q = Store.city(ctx)
        if (q.isEmpty()) {
            return "Скажи город, например: Нова, погода в Лондоне. Или впиши город в настройках приложения."
        }
        val place = geocode(q) ?: return "Не нашла город $q."
        val url = "https://api.open-meteo.com/v1/forecast?latitude=${place.lat}&longitude=${place.lon}" +
                "&current=temperature_2m,apparent_temperature,weather_code,wind_speed_10m" +
                "&daily=temperature_2m_max,temperature_2m_min,precipitation_probability_max" +
                "&timezone=auto&forecast_days=1&wind_speed_unit=ms"
        val j = JSONObject(get(url))
        val cur = j.getJSONObject("current")
        val temp = cur.getDouble("temperature_2m")
        val feels = cur.getDouble("apparent_temperature")
        val code = cur.getInt("weather_code")
        val wind = Math.round(cur.getDouble("wind_speed_10m")).toInt()

        val sb = StringBuilder()
        sb.append("Сейчас в ${place.name} ${describe(code)}, ${deg(temp)}")
        if (Math.round(feels) != Math.round(temp)) sb.append(", ощущается как ${deg(feels)}")
        sb.append(".")

        val d = j.optJSONObject("daily")
        val tmax = d?.optJSONArray("temperature_2m_max")?.optDouble(0) ?: Double.NaN
        val tmin = d?.optJSONArray("temperature_2m_min")?.optDouble(0) ?: Double.NaN
        val prob = d?.optJSONArray("precipitation_probability_max")?.optDouble(0) ?: Double.NaN
        if (!tmax.isNaN() && !tmin.isNaN()) {
            sb.append(" Днём до ${deg(tmax)}, ночью ${deg(tmin)}.")
        }
        if (!prob.isNaN() && prob >= 30) {
            val p = Math.round(prob).toInt()
            sb.append(" Вероятность осадков $p ${NumWords.plural(p, "процент", "процента", "процентов")}.")
        }
        if (wind > 0) {
            sb.append(" Ветер $wind ${NumWords.plural(wind, "метр", "метра", "метров")} в секунду.")
        }
        return sb.toString()
    }
}

package app.nova.assistant

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.PlaybackParams
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.CountDownLatch
import java.util.concurrent.FutureTask
import java.util.concurrent.TimeUnit

/** Живой голос через сервер Google (неофициально, бесплатно, нужен интернет). */
class OnlineVoice(ctx: Context) {
    private val app: Context = ctx.applicationContext

    @Volatile private var gen = 0
    @Volatile private var player: MediaPlayer? = null
    @Volatile private var latch: CountDownLatch? = null

    fun stop() {
        gen++
        try { player?.stop() } catch (e: Exception) {}
        latch?.countDown()
    }

    /** onFail вызывается, если голос не получили (тогда нужен запасной системный). */
    fun speak(text: String, pitch: Float, rate: Float, onEnd: () -> Unit, onFail: () -> Unit) {
        stop()
        val myGen = gen
        Thread {
            try {
                val chunks = split(text).take(8)
                if (chunks.isEmpty()) {
                    onEnd()
                    return@Thread
                }
                val futures = chunks.mapIndexed { i, c ->
                    val f = FutureTask<File?> { fetch(c, "nova_tts_${myGen}_$i.mp3") }
                    Thread(f).start()
                    f
                }
                val effPitch = (1f + (pitch - 1f) * 0.6f).coerceIn(0.5f, 2f)
                val effRate = rate.coerceIn(0.5f, 2f)
                for (i in futures.indices) {
                    if (myGen != gen) return@Thread
                    val file = try { futures[i].get(20, TimeUnit.SECONDS) } catch (e: Exception) { null }
                    if (file == null) {
                        if (i == 0 && myGen == gen) onFail() else if (myGen == gen) onEnd()
                        return@Thread
                    }
                    playFile(file, effPitch, effRate, myGen)
                    file.delete()
                }
                if (myGen == gen) onEnd()
            } catch (e: Exception) {
                if (myGen == gen) onFail()
            }
        }.start()
    }

    private fun playFile(f: File, pitch: Float, rate: Float, myGen: Int) {
        val done = CountDownLatch(1)
        latch = done
        val mp = MediaPlayer()
        player = mp
        try {
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .setUsage(AudioAttributes.USAGE_ASSISTANT)
                    .build()
            )
            mp.setDataSource(f.absolutePath)
            mp.setOnCompletionListener { done.countDown() }
            mp.setOnErrorListener { _, _, _ -> done.countDown(); true }
            mp.prepare()
            if (myGen != gen) return
            try {
                mp.playbackParams = PlaybackParams().setSpeed(rate).setPitch(pitch)
            } catch (e: Exception) {}
            mp.start()
            done.await(60, TimeUnit.SECONDS)
        } catch (e: Exception) {
            // пропускаем кусок
        } finally {
            if (player === mp) player = null
            try { mp.release() } catch (e: Exception) {}
        }
    }

    private fun fetch(chunk: String, name: String): File? {
        return try {
            val url = "https://translate.google.com/translate_tts?ie=UTF-8&client=tw-ob&tl=ru&q=" +
                    URLEncoder.encode(chunk, "UTF-8")
            val c = URL(url).openConnection() as HttpURLConnection
            try {
                c.connectTimeout = 8_000
                c.readTimeout = 15_000
                c.setRequestProperty(
                    "User-Agent",
                    "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120.0 Mobile Safari/537.36"
                )
                c.setRequestProperty("Referer", "https://translate.google.com/")
                if (c.responseCode !in 200..299) return null
                val bytes = c.inputStream.use { it.readBytes() }
                if (bytes.size < 800) return null
                val file = File(app.cacheDir, name)
                file.writeBytes(bytes)
                file
            } finally {
                c.disconnect()
            }
        } catch (e: Exception) {
            null
        }
    }

    /** Режет текст на куски до ~180 символов по предложениям. */
    private fun split(text: String): List<String> {
        val parts = Regex("(?<=[.!?…])\\s+").split(text.trim())
        val out = ArrayList<String>()
        var cur = ""
        for (p in parts) {
            var s = p.trim()
            while (s.length > 180) {
                var cut = s.lastIndexOf(' ', 180)
                if (cut < 40) cut = 180
                if (cur.isNotBlank()) { out.add(cur.trim()); cur = "" }
                out.add(s.substring(0, cut).trim())
                s = s.substring(cut).trim()
            }
            if (s.isEmpty()) continue
            if (cur.isNotEmpty() && cur.length + s.length + 1 > 180) {
                out.add(cur.trim())
                cur = ""
            }
            cur = if (cur.isEmpty()) s else "$cur $s"
        }
        if (cur.isNotBlank()) out.add(cur.trim())
        return out
    }
}

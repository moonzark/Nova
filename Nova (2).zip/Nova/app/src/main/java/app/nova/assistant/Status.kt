package app.nova.assistant

import android.os.Handler
import android.os.Looper

object Status {
    @Volatile
    var text: String = "Остановлена"
    var onChange: ((String) -> Unit)? = null

    fun set(s: String) {
        text = s
        Handler(Looper.getMainLooper()).post { onChange?.invoke(s) }
    }
}

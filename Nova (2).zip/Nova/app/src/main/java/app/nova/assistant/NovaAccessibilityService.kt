package app.nova.assistant

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class NovaAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: NovaAccessibilityService? = null
    }

    override fun onServiceConnected() {
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    fun back() = performGlobalAction(GLOBAL_ACTION_BACK)
    fun home() = performGlobalAction(GLOBAL_ACTION_HOME)
    fun recents() = performGlobalAction(GLOBAL_ACTION_RECENTS)

    fun lockScreen(): Boolean =
        Build.VERSION.SDK_INT >= 28 && performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)

    fun screenshot(): Boolean =
        Build.VERSION.SDK_INT >= 28 && performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)

    /** Открывает меню питания и нажимает «Выключение». Зависит от производителя телефона. */
    fun powerOff(onResult: (Boolean) -> Unit) {
        performGlobalAction(GLOBAL_ACTION_POWER_DIALOG)
        val h = Handler(Looper.getMainLooper())
        var tries = 0
        val words = listOf(
            "выключение", "выключить", "отключить питание", "отключение питания",
            "power off", "switch off"
        )
        val r = object : Runnable {
            override fun run() {
                tries++
                if (clickByText(words)) {
                    onResult(true)
                    return
                }
                if (tries < 8) h.postDelayed(this, 500) else onResult(false)
            }
        }
        h.postDelayed(r, 700)
    }

    private fun clickByText(words: List<String>): Boolean {
        val roots = mutableListOf<AccessibilityNodeInfo>()
        try {
            windows?.forEach { w -> w.root?.let { roots.add(it) } }
        } catch (e: Exception) {
        }
        rootInActiveWindow?.let { roots.add(it) }

        for (root in roots) {
            for (word in words) {
                val nodes = root.findAccessibilityNodeInfosByText(word) ?: continue
                for (n in nodes) {
                    var cur: AccessibilityNodeInfo? = n
                    while (cur != null) {
                        if (cur.isClickable) {
                            if (cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
                            break
                        }
                        cur = cur.parent
                    }
                }
            }
        }
        return false
    }
}

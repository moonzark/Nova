package app.nova.assistant

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import org.json.JSONArray
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService
import java.io.IOException

/**
 * Два режима:
 *  - Google-режим (по умолчанию): Vosk слушает только слово «Нова», а команду распознаёт Google.
 *  - Старый режим: всё распознаёт Vosk (офлайн, но хуже).
 */
class AssistantService : Service() {

    companion object {
        const val ACTION_STOP = "app.nova.assistant.STOP"
        private const val CHANNEL_ID = "nova"
        private const val NOTIF_ID = 1
    }

    private var model: Model? = null
    private var speech: SpeechService? = null
    private var voskRec: Recognizer? = null
    private var voskActive = false

    private var googleRec: SpeechRecognizer? = null
    private var googleBusy = false
    private var googleFailures = 0
    private var useGoogle = false
    private var followAfterSpeech = false
    private var speaking = false

    private var speaker: Speaker? = null
    private lateinit var router: CommandRouter
    private var awakeUntil = 0L
    private val main = Handler(Looper.getMainLooper())

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        router = CommandRouter(applicationContext) { text ->
            main.post {
                if (useGoogle) followAfterSpeech = true
                awakeUntil = System.currentTimeMillis() + Config.FOLLOWUP_MS
                speaker?.say(text)
            }
        }
        speaker = Speaker(
            this,
            onSpeakStart = {
                speaking = true
                if (voskActive) speech?.setPause(true)
            },
            onSpeakEnd = {
                main.postDelayed({
                    speaking = false
                    afterSpeech()
                }, 350)
            }
        )
        main.postDelayed(ticker, 15_000)
    }

    /** Раз в 15 секунд проверяет, не пора ли озвучить напоминание. */
    private val ticker: Runnable = object : Runnable {
        override fun run() {
            val due = Store.takeDue(applicationContext)
            if (due.isNotEmpty()) {
                speaker?.say("Напоминаю: " + due.joinToString(". "))
            }
            main.postDelayed(this, 15_000)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            Status.set("Нет доступа к микрофону")
            stopSelf()
            return START_NOT_STICKY
        }
        startInForeground()
        if (model == null) loadModel() else startVosk()
        return START_STICKY
    }

    private fun startInForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Nova", NotificationManager.IMPORTANCE_LOW)
        )
        val stop = PendingIntent.getService(
            this, 0,
            Intent(this, AssistantService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("Nova слушает")
            .setContentText("Скажи «Нова»")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .addAction(Notification.Action.Builder(null, "Остановить", stop).build())
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    private fun loadModel() {
        Thread {
            try {
                if (!ModelManager.isReady(this)) {
                    Status.set("Скачиваю модель речи (~45 МБ)…")
                    ModelManager.download(this) { p -> Status.set("Скачиваю модель: $p%") }
                }
                Status.set("Загрузка модели…")
                val m = Model(ModelManager.modelPath(this))
                main.post {
                    model = m
                    startVosk()
                }
            } catch (e: Exception) {
                Status.set("Ошибка модели: ${e.message}")
            }
        }.start()
    }

    // ------------------------------------------------------------------ Vosk

    private fun refreshMode() {
        useGoogle = Store.googleStt(this) && googleFailures < 3 &&
                SpeechRecognizer.isRecognitionAvailable(this)
    }

    /** Vosk в Google-режиме знает только слово активации: так он ошибается гораздо реже. */
    private fun grammarJson(): String {
        val arr = JSONArray()
        for (w in Config.WAKE_WORDS) if (!w.contains(' ')) arr.put(w)
        arr.put("[unk]")
        return arr.toString()
    }

    private fun startVosk() {
        val m = model ?: return
        try {
            stopVosk()
            refreshMode()
            val rec = if (useGoogle) Recognizer(m, 16000.0f, grammarJson()) else Recognizer(m, 16000.0f)
            voskRec = rec
            val s = SpeechService(rec, 16000.0f)
            speech = s
            s.startListening(listener)
            voskActive = true
            Status.set(
                if (useGoogle) "Слушаю: скажи «${Config.NAME}», потом команду"
                else "Слушаю (офлайн): скажи «${Config.NAME}»"
            )
        } catch (e: IOException) {
            Status.set("Ошибка микрофона: ${e.message}")
        }
    }

    private fun stopVosk() {
        voskActive = false
        try { speech?.stop() } catch (e: Exception) { }
        try { speech?.shutdown() } catch (e: Exception) { }
        speech = null
        try { voskRec?.close() } catch (e: Exception) { }
        voskRec = null
    }

    private fun norm(s: String) = s.lowercase().replace("ё", "е")

    private val listener = object : RecognitionListener {
        override fun onPartialResult(hypothesis: String?) {
            if (!useGoogle || googleBusy) return
            val p = try { JSONObject(hypothesis ?: "{}").optString("partial") } catch (e: Exception) { "" }
            if (p.isNotBlank() && findWakeEnd(norm(p)) >= 0) startGoogle(false)
        }

        override fun onResult(hypothesis: String?) {
            val text = try {
                JSONObject(hypothesis ?: "{}").optString("text")
            } catch (e: Exception) {
                ""
            }
            if (useGoogle) {
                if (!googleBusy && text.isNotBlank() && findWakeEnd(norm(text)) >= 0) startGoogle(false)
            } else {
                handleText(text)
            }
        }

        override fun onFinalResult(hypothesis: String?) {}
        override fun onError(exception: Exception?) {
            Status.set("Ошибка: ${exception?.message}")
        }
        override fun onTimeout() {}
    }

    // ---------------------------------------------------------------- Google

    private fun beep() {
        try {
            val tg = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 70)
            tg.startTone(ToneGenerator.TONE_PROP_ACK, 120)
            main.postDelayed({ tg.release() }, 500)
        } catch (e: Exception) {
        }
    }

    private val googleTimeout = Runnable {
        if (googleBusy) {
            finishGoogle()
            resumeWake()
        }
    }

    private fun startGoogle(follow: Boolean) {
        if (googleBusy) return
        googleBusy = true
        stopVosk()
        if (!follow) beep()
        try {
            val sr = SpeechRecognizer.createSpeechRecognizer(this)
            googleRec = sr
            sr.setRecognitionListener(googleListener)
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
                .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
                .putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
            sr.startListening(i)
            Status.set(if (follow) "Слушаю ответ…" else "Слушаю команду…")
            main.postDelayed(googleTimeout, 15_000)
        } catch (e: Exception) {
            googleFailures++
            Status.set("Ошибка Google-распознавания: ${e.message}")
            finishGoogle()
            startVosk()
        }
    }

    private fun finishGoogle() {
        main.removeCallbacks(googleTimeout)
        try { googleRec?.cancel() } catch (e: Exception) { }
        try { googleRec?.destroy() } catch (e: Exception) { }
        googleRec = null
        googleBusy = false
    }

    private fun resumeWake() {
        if (!voskActive && !googleBusy && !speaking) startVosk()
    }

    private val googleListener = object : android.speech.RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onError(error: Int) {
            finishGoogle()
            if (error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) {
                Status.set("Не расслышала. Скажи «${Config.NAME}» ещё раз")
            } else {
                googleFailures++
                Status.set("Ошибка Google-распознавания: код $error")
            }
            resumeWake()
        }

        override fun onResults(results: Bundle?) {
            val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull() ?: ""
            finishGoogle()
            if (text.isBlank()) {
                resumeWake()
                return
            }
            googleFailures = 0
            handleGoogle(text)
        }
    }

    private fun afterSpeech() {
        if (googleBusy) return
        if (!useGoogle) {
            speech?.setPause(false)
            return
        }
        if (followAfterSpeech) {
            followAfterSpeech = false
            startGoogle(true)
        } else if (!voskActive) {
            startVosk()
        } else {
            speech?.setPause(false)
        }
    }

    private fun handleGoogle(raw: String) {
        var command = norm(raw).trim(' ', ',', '.', '!', '?')
        for (w in Config.WAKE_WORDS) {
            if (command == w || command.startsWith("$w ") || command.startsWith("$w,")) {
                command = command.removePrefix(w).trim(' ', ',', '.', '!', '?')
                break
            }
        }
        Status.set("Распознано: $command")
        val reply = if (command.isBlank()) {
            followAfterSpeech = true
            "Слушаю."
        } else {
            router.handle(command)
        }
        if (router.awaitingConfirm()) followAfterSpeech = true
        if (reply.isNotBlank()) {
            speaker?.say(reply)
        } else {
            // ответ придёт позже из интернета; на случай сбоя возвращаемся к прослушиванию
            main.postDelayed({ resumeWake() }, 40_000)
        }
    }

    // ------------------------------------------------------- Старый (офлайн) режим

    /** Возвращает индекс конца слова «Нова» в тексте или -1 */
    private fun findWakeEnd(t: String): Int {
        for (w in Config.WAKE_WORDS) {
            val m = Regex("(^|\\s)" + Regex.escape(w) + "(\\s|$)").find(t)
            if (m != null) return m.range.last + 1
        }
        return -1
    }

    private fun handleText(text: String) {
        if (text.isBlank()) return
        val t = norm(text)
        val now = System.currentTimeMillis()

        val wakeEnd = findWakeEnd(t)
        val command: String? = when {
            wakeEnd >= 0 -> t.substring(minOf(wakeEnd, t.length)).trim()
            now < awakeUntil -> t
            else -> null
        }
        if (command == null) return

        Status.set("Распознано: $t")
        awakeUntil = 0

        val reply = if (command.isBlank()) {
            awakeUntil = now + Config.AWAKE_MS
            "Слушаю."
        } else {
            router.handle(command)
        }
        if (router.awaitingConfirm()) {
            awakeUntil = System.currentTimeMillis() + Config.CONFIRM_MS
        }
        if (reply.isNotBlank()) speaker?.say(reply)
    }

    override fun onDestroy() {
        main.removeCallbacksAndMessages(null)
        finishGoogle()
        stopVosk()
        model?.close()
        speaker?.shutdown()
        Status.set("Остановлена")
        super.onDestroy()
    }
}

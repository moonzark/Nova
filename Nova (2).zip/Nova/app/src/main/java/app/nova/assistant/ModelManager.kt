package app.nova.assistant

import android.content.Context
import java.io.File
import java.io.FileOutputStream
import java.io.FilterInputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

/** Скачивает русскую модель Vosk при первом запуске (нужен интернет один раз). */
object ModelManager {
    private const val URL_ZIP = "https://alphacephei.com/vosk/models/vosk-model-small-ru-0.22.zip"

    private fun dir(ctx: Context) = File(ctx.filesDir, "vosk-model")
    fun modelPath(ctx: Context): String = dir(ctx).absolutePath
    fun isReady(ctx: Context): Boolean = File(dir(ctx), ".ok").exists()

    fun download(ctx: Context, onProgress: (Int) -> Unit) {
        val target = dir(ctx)
        target.deleteRecursively()
        target.mkdirs()
        val canonical = target.canonicalPath

        val conn = URL(URL_ZIP).openConnection() as HttpURLConnection
        conn.connectTimeout = 15000
        conn.readTimeout = 30000
        conn.connect()
        if (conn.responseCode != 200) throw IOException("HTTP ${conn.responseCode}")

        val total = conn.contentLengthLong
        var read = 0L
        var lastPct = -1
        fun bump(n: Int) {
            read += n
            if (total > 0) {
                val pct = (read * 100 / total).toInt()
                if (pct != lastPct) {
                    lastPct = pct
                    onProgress(pct)
                }
            }
        }

        val counting = object : FilterInputStream(conn.inputStream) {
            override fun read(): Int {
                val b = super.read()
                if (b >= 0) bump(1)
                return b
            }

            override fun read(b: ByteArray, off: Int, len: Int): Int {
                val n = super.read(b, off, len)
                if (n > 0) bump(n)
                return n
            }
        }

        ZipInputStream(counting.buffered()).use { zin ->
            var e = zin.nextEntry
            while (e != null) {
                val name = e.name.substringAfter('/', "")  // убираем верхнюю папку
                if (name.isNotEmpty()) {
                    val out = File(target, name)
                    if (!out.canonicalPath.startsWith(canonical + File.separator)) {
                        throw IOException("bad zip entry")
                    }
                    if (e.isDirectory) {
                        out.mkdirs()
                    } else {
                        out.parentFile?.mkdirs()
                        FileOutputStream(out).use { zin.copyTo(it) }
                    }
                }
                zin.closeEntry()
                e = zin.nextEntry
            }
        }
        File(target, ".ok").writeText("ok")
    }
}

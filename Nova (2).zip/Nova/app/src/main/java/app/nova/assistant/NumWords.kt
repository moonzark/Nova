package app.nova.assistant

/** Разбор русских числительных (Vosk выдаёт числа словами) и времени. */
object NumWords {
    data class Hit(val value: Int, val start: Int, val end: Int)
    data class Dur(val millis: Long, val end: Int)
    data class Clk(val hour: Int, val minute: Int, val hadModifier: Boolean, val start: Int, val end: Int)

    private val units = mapOf(
        "ноль" to 0, "один" to 1, "одна" to 1, "одну" to 1, "одно" to 1,
        "два" to 2, "две" to 2, "три" to 3, "четыре" to 4, "пять" to 5,
        "шесть" to 6, "семь" to 7, "восемь" to 8, "девять" to 9
    )
    private val teens = mapOf(
        "десять" to 10, "одиннадцать" to 11, "двенадцать" to 12, "тринадцать" to 13,
        "четырнадцать" to 14, "пятнадцать" to 15, "шестнадцать" to 16,
        "семнадцать" to 17, "восемнадцать" to 18, "девятнадцать" to 19
    )
    private val tens = mapOf(
        "двадцать" to 20, "тридцать" to 30, "сорок" to 40, "пятьдесят" to 50,
        "шестьдесят" to 60, "семьдесят" to 70, "восемьдесят" to 80, "девяносто" to 90
    )
    private val hundreds = mapOf(
        "сто" to 100, "двести" to 200, "триста" to 300, "четыреста" to 400, "пятьсот" to 500,
        "шестьсот" to 600, "семьсот" to 700, "восемьсот" to 800, "девятьсот" to 900
    )

    private fun scale(w: String): Int = when {
        w.toIntOrNull() != null -> 5
        hundreds.containsKey(w) -> 4
        tens.containsKey(w) -> 3
        teens.containsKey(w) -> 2
        units.containsKey(w) -> 1
        else -> 0
    }

    private fun value(w: String): Int =
        w.toIntOrNull() ?: hundreds[w] ?: tens[w] ?: teens[w] ?: units[w] ?: 0

    /** Все числа в списке слов: «двадцать пять» = 25, «семь тридцать» = 7 и 30. */
    fun hits(words: List<String>): List<Hit> {
        val out = mutableListOf<Hit>()
        var i = 0
        while (i < words.size) {
            val s = scale(words[i])
            if (s == 0) { i++; continue }
            val start = i
            var total = value(words[i])
            if (s == 5) { out.add(Hit(total, i, i + 1)); i++; continue }
            var prev = if (s == 2) 0 else s
            i++
            while (i < words.size) {
                val s2 = scale(words[i])
                if (s2 == 0 || s2 == 5 || s2 >= prev) break
                total += value(words[i])
                prev = if (s2 == 2) 0 else s2
                i++
            }
            out.add(Hit(total, start, i))
        }
        return out
    }

    private fun unitMs(w: String?): Long? = when {
        w == null -> null
        w.startsWith("секунд") -> 1000L
        w.startsWith("минут") -> 60_000L
        w.startsWith("час") -> 3_600_000L
        else -> null
    }

    /** «пять минут», «полчаса», «час», «один час тридцать минут» */
    fun duration(words: List<String>): Dur? {
        val byStart = hits(words).associateBy { it.start }
        var total = 0L
        var end = -1
        var i = 0
        while (i < words.size) {
            if (end >= 0 && i > end) break
            val w = words[i]
            val h = byStart[i]
            if (w == "полчаса") { total += 30 * 60_000L; end = i + 1; i++; continue }
            if (w == "полтора" && words.getOrNull(i + 1)?.startsWith("час") == true) {
                total += 90 * 60_000L; end = i + 2; i += 2; continue
            }
            if (h != null) {
                val u = unitMs(words.getOrNull(h.end))
                if (u != null) {
                    total += h.value * u
                    end = h.end + 1
                    i = h.end + 1
                } else {
                    i = h.end
                }
                continue
            }
            val u1: Long? = when {
                w.startsWith("секунду") -> 1000L
                w.startsWith("минуту") -> 60_000L
                w == "час" -> 3_600_000L
                else -> null
            }
            if (u1 != null) { total += u1; end = i + 1 }
            i++
        }
        return if (end >= 0 && total > 0) Dur(total, end) else null
    }

    /** «в семь тридцать», «на восемь утра», «в пять вечера» */
    fun clock(words: List<String>): Clk? {
        val hs = hits(words)
        val marks = setOf("в", "на", "к", "до", "ко")
        val first = hs.firstOrNull { it.value in 0..24 && it.start > 0 && words[it.start - 1] in marks }
            ?: hs.firstOrNull { it.value in 0..24 }
            ?: return null
        var minute = 0
        var end = first.end
        val n1 = hs.firstOrNull { it.start == first.end }
        if (n1 != null) {
            if (n1.value == 0) {
                val n2 = hs.firstOrNull { it.start == n1.end }
                if (n2 != null && n2.value in 0..9) { minute = n2.value; end = n2.end } else { end = n1.end }
            } else if (n1.value in 1..59) {
                minute = n1.value; end = n1.end
            }
        }
        var hour = first.value
        var mod = false
        val limit = minOf(end + 2, words.size)
        var j = end
        while (j < limit) {
            when (words[j]) {
                "вечера", "дня" -> { if (hour in 1..11) hour += 12; mod = true; end = j + 1; break }
                "ночи" -> { if (hour == 12) hour = 0; mod = true; end = j + 1; break }
                "утра" -> { mod = true; end = j + 1; break }
            }
            j++
        }
        if (hour == 24) hour = 0
        return Clk(hour, minute, mod, first.start, end)
    }

    fun plural(n: Int, one: String, few: String, many: String): String {
        val m100 = n % 100
        val m10 = n % 10
        return when {
            m100 in 11..14 -> many
            m10 == 1 -> one
            m10 in 2..4 -> few
            else -> many
        }
    }

    fun spoken(ms: Long): String {
        val h = (ms / 3_600_000).toInt()
        val m = ((ms % 3_600_000) / 60_000).toInt()
        val s = ((ms % 60_000) / 1000).toInt()
        val parts = mutableListOf<String>()
        if (h > 0) parts.add("$h " + plural(h, "час", "часа", "часов"))
        if (m > 0) parts.add("$m " + plural(m, "минуту", "минуты", "минут"))
        if (s > 0) parts.add("$s " + plural(s, "секунду", "секунды", "секунд"))
        return parts.joinToString(" ")
    }
}
